var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["1a5e8447-9343-4c2d-aaa1-d2a4661f4ff2","ec6ffa18-58e6-43fe-9907-33939304fd47","1c88f488-111f-477a-aa3b-fdade9266763","b33ede88-dfca-42b7-ae08-47db3ab181c8","870f1453-cc6f-4497-a304-c91c855c31b0"],"propsByKey":{"1a5e8447-9343-4c2d-aaa1-d2a4661f4ff2":{"name":"inimigo","sourceUrl":null,"frameSize":{"x":96,"y":140},"frameCount":1,"looping":true,"frameDelay":12,"version":"HWVawVmmzPUIbfUap4kDP58gtJoGs9J.","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":96,"y":140},"rootRelativePath":"assets/1a5e8447-9343-4c2d-aaa1-d2a4661f4ff2.png"},"ec6ffa18-58e6-43fe-9907-33939304fd47":{"name":"link","sourceUrl":null,"frameSize":{"x":201,"y":300},"frameCount":1,"looping":true,"frameDelay":12,"version":"n_mHiAj5wxuxAOSTgqsfEagzfqP1n6qW","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":201,"y":300},"rootRelativePath":"assets/ec6ffa18-58e6-43fe-9907-33939304fd47.png"},"1c88f488-111f-477a-aa3b-fdade9266763":{"name":"mastersword","sourceUrl":null,"frameSize":{"x":500,"y":574},"frameCount":1,"looping":true,"frameDelay":12,"version":"yYFVsQ_XzyoPQ_LywZm29FanDWUL8ACa","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":500,"y":574},"rootRelativePath":"assets/1c88f488-111f-477a-aa3b-fdade9266763.png"},"b33ede88-dfca-42b7-ae08-47db3ab181c8":{"name":"fim","sourceUrl":"assets/v3/animations/bK6HvxRTa8LRy9tzoP-QAvtLVj-cCPmjm0-pfL5bIsg/b33ede88-dfca-42b7-ae08-47db3ab181c8.png","frameSize":{"x":600,"y":600},"frameCount":1,"looping":true,"frameDelay":4,"version":"HPBVXXFsYPBsgqieLU5DkU_hMmcSjVPp","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":600,"y":600},"rootRelativePath":"assets/v3/animations/bK6HvxRTa8LRy9tzoP-QAvtLVj-cCPmjm0-pfL5bIsg/b33ede88-dfca-42b7-ae08-47db3ab181c8.png"},"870f1453-cc6f-4497-a304-c91c855c31b0":{"name":"gameover","sourceUrl":"assets/v3/animations/bK6HvxRTa8LRy9tzoP-QAvtLVj-cCPmjm0-pfL5bIsg/870f1453-cc6f-4497-a304-c91c855c31b0.png","frameSize":{"x":300,"y":168},"frameCount":1,"looping":true,"frameDelay":4,"version":"aFpVLOKAfQ5tA1sYGg3fy04KDnx.ApF6","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":300,"y":168},"rootRelativePath":"assets/v3/animations/bK6HvxRTa8LRy9tzoP-QAvtLVj-cCPmjm0-pfL5bIsg/870f1453-cc6f-4497-a304-c91c855c31b0.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----


playSound("assets/08-Hyrule-Field-Main-Theme.mp3", true);


var parede1 = createSprite(200, 300, 200, 6);
var parede2 = createSprite(200, 100, 200, 6);
var parede3 = createSprite(100, 123, 6, 50);
var parede4 = createSprite(100, 277, 6, 50);
var parede5 = createSprite(47, 150, 110, 6);
var parede6 = createSprite(47, 250, 110, 6);
var parede7 = createSprite(300, 277, 6, 50);
var parede8 = createSprite(300, 123, 6, 50);
var parede9 = createSprite(353, 150, 110, 6);
var parede10 = createSprite(353, 250, 110, 6);

var link = createSprite(50, 200, 15, 15);


var inimigo1 = createSprite(130, 200, 15, 15);
var inimigo2 = createSprite(200, 200, 15, 15);
var inimigo3 = createSprite(270, 200, 15, 15);

var mastersword = createSprite(350, 190, 20, 20);
mastersword.setAnimation("mastersword");
mastersword.scale = ("0.12");





inimigo1.setAnimation("inimigo");
inimigo2.setAnimation("inimigo");
inimigo3.setAnimation("inimigo");


inimigo1.scale = ("0.3");
inimigo2.scale = ("0.3");
inimigo3.scale = ("0.3");





link.setAnimation("link");
link.scale = ("0.12");






  inimigo1.velocityY = ("5");
  inimigo2.velocityY = ("-5");
  inimigo3.velocityY = ("5");
  

function draw() {
  background("white");
  


  

inimigo1.bounceOff(parede1);
inimigo1.bounceOff(parede2);
inimigo2.bounceOff(parede1);
inimigo2.bounceOff(parede2);
inimigo3.bounceOff(parede1);
inimigo3.bounceOff(parede2);
 

link.velocityX = (0);

 
if (keyDown("d")) {
  link.velocityX = (5);
}
if (keyDown("a")) {
  link.velocityX = (-5);
}



 
 if (link.isTouching(inimigo1)) {
    var gameover = createSprite(200, 200);
    gameover.setAnimation("gameover");
    gameover.scale = ("3");
    
    
  }
   
   if (link.isTouching(inimigo2)) {
     var gameover = createSprite(200, 200);
    gameover.setAnimation("gameover");
    gameover.scale = ("3");
  }

  if (link.isTouching(inimigo3)) {
     var gameover = createSprite(200, 200);
    gameover.setAnimation("gameover");
    gameover.scale = ("3");
  }
   
  if (link.isTouching(mastersword)) {
  var fim = createSprite(200, 200);
  fim.setAnimation("fim");
  fim.scale = ("0.7");
  
     
  }
  
  
  
  
  
  
  
  drawSprites();
  
  
  
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
